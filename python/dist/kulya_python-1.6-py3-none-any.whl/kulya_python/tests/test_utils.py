"""import unittest
from kulya_python.utils import getNodeByPath

class TestUtils(unittest.TestCase):
    def test_getNodeByPath(self):
        # Exemple de test
        node = getNodeByPath("some/path")
        self.assertEqual(node.getNameFr(), "Nom attendu")

if __name__ == '__main__':
    unittest.main()"""
