# kuliya for python
## **How to Use**
1. **Run the script** with the JSON file path as an argument:
   ```bash
   python3 main.py <path-to-json-file>
   ```
